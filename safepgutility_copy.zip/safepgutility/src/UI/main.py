from PySide6.QtWidgets import QMainWindow, QWidget, QFileDialog, QProgressBar, QLabel, QMessageBox, QTableWidgetItem, QLineEdit
from PySide6.QtGui import QDoubleValidator
from PySide6.QtCore import QTimer, Qt
from UI.Templates.main_window_2 import Ui_MainWindow
import json

class MainWindow(QMainWindow):
    def __init__(self):
        super(MainWindow, self).__init__()
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)
        self.setup_connections()
        self.setup_submit_buttons()
        self.setup_text_changed_connections()
        self.overlay = None
        self.progress_bar = self.ui.progressBar
        self.progress_bar.setMaximum(100)
        self.progress_bar.hide()
        self.ui.textBrowser.setReadOnly(True) 
 
        self.temp_adder_1 = self.ui.temp_adder_1
        self.temp_adder_2 = self.ui.temp_adder_2
        self.stress_multiplier_1 = self.ui.stress_multiplier_1
        self.stress_multiplier_2 = self.ui.stress_multiplier_2

        self.setup_validators()
        self.temp_adder_1.textChanged.connect(self.validate_temperature)
        self.temp_adder_2.textChanged.connect(self.validate_temperature)

        self.setup_stress_validators()
        self.stress_multiplier_1.textChanged.connect(self.validate_stress)
        self.stress_multiplier_2.textChanged.connect(self.validate_stress)

    def setup_validators(self):
        double_validator = QDoubleValidator()
        double_validator.setRange(-273.15, 1000.0) 
        self.temp_adder_1.setValidator(double_validator)
        self.temp_adder_2.setValidator(double_validator)

    def setup_stress_validators(self):
        double_validator = QDoubleValidator()
        double_validator.setRange(0 , 100)
        self.stress_multiplier_1.setValidator(double_validator)
        self.stress_multiplier_2.setValidator(double_validator)

    def validate_temperature(self):
        temp_line_edits = [self.temp_adder_1, self.temp_adder_2]
        self.validate_line_edits(temp_line_edits, -273.15, 1000.0)

    def validate_stress(self):
        stress_line_edits = [self.stress_multiplier_1, self.stress_multiplier_2]
        self.validate_line_edits(stress_line_edits, 0, 100)

    def validate_line_edits(self, line_edits, min_value, max_value):
        valid = True
        warning_message = ""

        for line_edit in line_edits:
            text = line_edit.text()
            if text.strip() == "":
                line_edit.setStyleSheet(line_edit.original_stylesheet)
                line_edit.setToolTip("")
                continue

            try:
                value = float(text)
                print(f"Validated value for {line_edit.objectName()}: {value}")
                if value < min_value or value > max_value:
                    raise ValueError("Invalid Value")
                line_edit.setStyleSheet(line_edit.original_stylesheet)
                line_edit.setToolTip("")
            except ValueError as e:
                valid = False
                if not hasattr(line_edit, 'original_stylesheet'):
                    line_edit.original_stylesheet = line_edit.styleSheet()
                line_edit.setStyleSheet("border: 2px solid red;background-color: #ffffff;border-radius: 6px;")
                line_edit.setToolTip(str(e))
                warning_message += f"Invalid value in {line_edit.objectName()}\n"
                print(f"Validation error for {line_edit.objectName()}: {e}")

        # Debugging: Print tooltips for verification
        for line_edit in line_edits:
            print(f"{line_edit.objectName()} tooltip: {line_edit.toolTip()}")

        if not valid:
            for line_edit in line_edits:
                line_edit.setToolTip(warning_message.strip())

        
    def setup_connections(self):
        self.ui.pushButton.clicked.connect(
            lambda: self.browse_file(self.ui.local_xml_path)
        )
        self.ui.pushButton_2.clicked.connect(
            lambda: self.browse_file(self.ui.global_xml_path)
        )
        self.ui.pushButton_3.clicked.connect(
            lambda: self.browse_file(self.ui.tmf_input_file_path)
        )
        self.ui.pushButton_4.clicked.connect(
            lambda: self.browse_file(self.ui.xml_file_mmpa)
        )
        self.ui.actionOpen.triggered.connect(self.open_file)
        self.ui.actionSave.triggered.connect(self.save_file)
        self.ui.actionSave_As.triggered.connect(self.save_file_as)

    def setup_submit_buttons(self):
        self.ui.pushButton_5.setEnabled(False)
        self.ui.pushButton_5.setStyleSheet("background-color: gray; color: white;")
        self.ui.pushButton_6.setEnabled(False)
        self.ui.pushButton_6.setStyleSheet("background-color: gray; color: white;")

    def setup_text_changed_connections(self):
        self.ui.local_xml_path.textChanged.connect(self.check_files)
        self.ui.global_xml_path.textChanged.connect(self.check_files)
        self.ui.tmf_input_file_path.textChanged.connect(self.check_files)
        self.ui.xml_file_mmpa.textChanged.connect(self.check_files)

    def open_file(self):
        fname, _ = QFileDialog.getOpenFileName(self, "Open File", "", "JSON Files (*.json);;All Files (*)")
        if fname:
            try:
                with open(fname, 'r') as file:
                    data = json.load(file)
                    print(f"Loaded data: {data}")
                    self.ui.local_xml_path.setText(data.get("local_xml_path", ""))
                    self.ui.global_xml_path.setText(data.get("global_xml_path", ""))
                    self.ui.tmf_input_file_path.setText(data.get("tmf_input_file_path", ""))
                    self.ui.xml_file_mmpa.setText(data.get("xml_file_mmpa", ""))
                
                    if hasattr(self.ui, 'plainTextEdit'):
                        self.ui.plainTextEdit.setPlainText(data.get("plainTextEdit_content", ""))
                
                    if hasattr(self.ui, 'tableWidget'):
                        table_data = data.get("table_data", [])
                        self.populate_table(table_data)
                
                    if hasattr(self.ui, 'comboBox'):
                        self.ui.comboBox.setCurrentText(data.get("comboBox_selection", ""))
                
                    if hasattr(self.ui, 'checkBox'):
                        self.ui.checkBox.setChecked(data.get("checkBox_state", False))
                    
                    self.log_action("File processing completed.")
                    
            except Exception as e:
                print(f"Error opening or reading file: {e}")
                QMessageBox.warning(self, "Open Error", f"Error opening file: {e}")

    def populate_table(self, table_data):
        self.ui.tableWidget.clearContents()
        self.ui.tableWidget.setRowCount(len(table_data))
        if table_data:
            for row, rowData in enumerate(table_data):
                for column, value in enumerate(rowData):
                    item = QTableWidgetItem(value)
                    self.ui.tableWidget.setItem(row, column, item)

    def save_file(self):
        fname = self.ui.local_xml_path.text()
        print(f"Saving to file: {fname}")
        if fname:
            data = self.collect_data()
            print(f"Data to be saved: {data}")
            try:
                with open(fname, 'w') as file:
                    json.dump(data, file, indent=4)
                print(f"File saved: {fname}")
            except Exception as e:
                print(f"Error saving file: {e}")
                QMessageBox.warning(self, "Save Error", f"Error saving file: {e}")
        else:
            QMessageBox.warning(self, "Save Error", "No file path specified!")

    def save_file_as(self):
        fname, _ = QFileDialog.getSaveFileName(self, "Save File As", "", "JSON Files (*.json);;All Files (*)")
        print(f"Saving file as: {fname}")
        if fname:
            data = self.collect_data()
            print(f"Data to be saved: {data}")
            try:
                with open(fname, 'w') as file:
                    json.dump(data, file, indent=4)
                self.ui.local_xml_path.setText(fname)
                print(f"File saved as: {fname}")
            except Exception as e:
                print(f"Error saving file as: {e}")
                QMessageBox.warning(self, "Save Error", f"Error saving file as: {e}")

    def collect_data(self):
        table_data = []
        if hasattr(self.ui, 'tableWidget'):
            for row in range(self.ui.tableWidget.rowCount()):
                row_data = []
                for column in range(self.ui.tableWidget.columnCount()):
                    item = self.ui.tableWidget.item(row, column)
                    row_data.append(item.text() if item else "")
                table_data.append(row_data)

        data = {
            "local_xml_path": self.ui.local_xml_path.text(),
            "global_xml_path": self.ui.global_xml_path.text(),
            "tmf_input_file_path": self.ui.tmf_input_file_path.text(),
            "xml_file_mmpa": self.ui.xml_file_mmpa.text(),
            "plainTextEdit_content": self.ui.plainTextEdit.toPlainText() if hasattr(self.ui, 'plainTextEdit') else "",
            "table_data": table_data,
            "comboBox_selection": self.ui.comboBox.currentText() if hasattr(self.ui, 'comboBox') else "",
            "checkBox_state": self.ui.checkBox.isChecked() if hasattr(self.ui, 'checkBox') else False
        }

        if hasattr(self.ui, 'tabWidget'):
            tab_data = []
            for i in range(self.ui.tabWidget.count()):
                tab = self.ui.tabWidget.widget(i)
                tab_data.append(f"Tab {i}: {tab.objectName()}")
            data["tab_data"] = tab_data

        return data

    def browse_file(self, line_edit):
        self.show_blur_effect()
        fname, _ = QFileDialog.getOpenFileName(self, "Open File", "L:\\Internship", "All Files (*)")
        self.hide_blur_effect()
        if fname:
            line_edit.setText(fname)
            self.log_action(f"Selected file for {line_edit.objectName()}: {fname}")
            self.ui.progressBar.show()
            self.ui.progressBar.setValue(0)
            self.upload_file(fname)


    def upload_file(self, fname):
        self.simulate_upload(0, fname)

    def simulate_upload(self, value, fname):
        if value <= 100:
            value += 10
            self.ui.progressBar.setValue(value)
            QTimer.singleShot(200, lambda: self.simulate_upload(value, fname))
        else:
            self.ui.progressBar.hide()
            self.log_action(f"Upload complete for file: {fname}")
            self.log_action_1("File processing completed.")

    def show_blur_effect(self):
        self.overlay = QWidget(self)
        self.overlay.setGeometry(self.rect())
        self.overlay.setStyleSheet("background-color: rgba(0, 0, 0, 100);")
        self.overlay.setAttribute(Qt.WA_TransparentForMouseEvents)
        self.overlay.show()

    def hide_blur_effect(self):
        if self.overlay:
            self.overlay.hide()

    def log_action(self, message):
        self.ui.textBrowser_22.append(message)
        self.ui.textBrowser_22.textChanged.connect(self.AddnRefresh)
        print(message)

    def log_action_1(self, message):
        self.ui.textBrowser.append(message)
        self.ui.textBrowser.textChanged.connect(self.AddnRefresh)
        print(message)

    def AddnRefresh(self):
        self.ui.textBrowser.verticalScrollBar().setValue(
            self.ui.textBrowser.verticalScrollBar().maximum()
        )

    def check_files(self):
        if self.ui.local_xml_path.text() and self.ui.global_xml_path.text():
            self.ui.pushButton_5.setEnabled(True)
            self.ui.pushButton_5.setStyleSheet(
                "background-color: rgb(167, 255, 200); color: rgb(148, 0, 111);"
            )
        else:
            self.ui.pushButton_5.setEnabled(False)
            self.ui.pushButton_5.setStyleSheet("background-color: gray; color: white;")

        if self.ui.local_xml_path.text() and self.ui.global_xml_path.text() and self.ui.tmf_input_file_path.text():
            self.ui.pushButton_6.setEnabled(True)
            self.ui.pushButton_6.setStyleSheet(
                "background-color: rgb(167, 255, 200); color: rgb(148, 0, 111);"
            )
        else:
            self.ui.pushButton_6.setEnabled(False)
            self.ui.pushButton_6.setStyleSheet("background-color: gray; color: white;")
    
    