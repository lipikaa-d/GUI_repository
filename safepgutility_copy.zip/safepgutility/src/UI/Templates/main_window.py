# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'main_windowJpevla.ui'
##
## Created by: Qt User Interface Compiler version 6.7.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (
    QCoreApplication,
    QDate,
    QDateTime,
    QLocale,
    QMetaObject,
    QObject,
    QPoint,
    QRect,
    QSize,
    QTime,
    QUrl,
    Qt,
)
from PySide6.QtGui import (
    QBrush,
    QColor,
    QConicalGradient,
    QCursor,
    QFont,
    QFontDatabase,
    QGradient,
    QIcon,
    QImage,
    QKeySequence,
    QLinearGradient,
    QPainter,
    QPalette,
    QPixmap,
    QRadialGradient,
    QTransform,
)
from PySide6.QtWidgets import (
    QApplication,
    QCheckBox,
    QFormLayout,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QLayout,
    QLineEdit,
    QMainWindow,
    QProgressBar,
    QPushButton,
    QSizePolicy,
    QSpacerItem,
    QTabWidget,
    QTextBrowser,
    QVBoxLayout,
    QWidget,
)


class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        if not MainWindow.objectName():
            MainWindow.setObjectName("MainWindow")
        MainWindow.resize(808, 807)
        self.centralwidget = QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.tabWidget = QTabWidget(self.centralwidget)
        self.tabWidget.setObjectName("tabWidget")
        self.tabWidget.setGeometry(QRect(10, 10, 781, 771))
        self.tabWidget.setSizeIncrement(QSize(0, 40))
        self.tabWidget.setStyleSheet(
            "/* Main Window Style */\n"
            "QWidget {\n"
            "    background-color: rgb(255, 204, 255);  /* Pinkish background */\n"
            "}"
        )
        self.tab = QWidget()
        self.tab.setObjectName("tab")
        self.horizontalLayoutWidget = QWidget(self.tab)
        self.horizontalLayoutWidget.setObjectName("horizontalLayoutWidget")
        self.horizontalLayoutWidget.setGeometry(QRect(10, -1, 639, 44))
        self.horizontalLayout = QHBoxLayout(self.horizontalLayoutWidget)
        self.horizontalLayout.setObjectName("horizontalLayout")
        self.horizontalLayout.setSizeConstraint(QLayout.SizeConstraint.SetNoConstraint)
        self.horizontalLayout.setContentsMargins(0, 0, 0, 0)
        self.Number_label = QLabel(self.horizontalLayoutWidget)
        self.Number_label.setObjectName("Number_label")
        sizePolicy = QSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.Number_label.sizePolicy().hasHeightForWidth())
        self.Number_label.setSizePolicy(sizePolicy)
        self.Number_label.setLayoutDirection(Qt.LayoutDirection.RightToLeft)
        self.Number_label.setStyleSheet(
            "/* Title Label Style */\n"
            "QLabel#Number_label {\n"
            "    background-color:rgb(44, 120, 127);  /* Bluish background */\n"
            "    color: white;               /* Font color for the text */\n"
            '    font: 14pt "MS Shell Dlg 2";\n'
            "    padding: 5px;\n"
            "    border-radius: 10px;                   /* Rounded corners */\n"
            "    border: 2px solid rgb(85, 0, 127);           \n"
            "}\n"
            ""
        )

        self.horizontalLayout.addWidget(self.Number_label)

        self.text = QLabel(self.horizontalLayoutWidget)
        self.text.setObjectName("text")
        sizePolicy.setHeightForWidth(self.text.sizePolicy().hasHeightForWidth())
        self.text.setSizePolicy(sizePolicy)
        self.text.setLayoutDirection(Qt.LayoutDirection.LeftToRight)
        self.text.setStyleSheet(
            "\n"
            "QLabel#text{\n"
            " background-color: rgb(255, 204, 255);\n"
            "color: black;                /* Font color */\n"
            'font: bold 17pt "Arial Narrow";\n'
            " font-weight: normal;\n"
            "}\n"
            "\n"
            ""
        )

        self.horizontalLayout.addWidget(self.text)

        self.gridLayoutWidget = QWidget(self.tab)
        self.gridLayoutWidget.setObjectName("gridLayoutWidget")
        self.gridLayoutWidget.setGeometry(QRect(10, 50, 751, 509))
        self.gridLayout = QGridLayout(self.gridLayoutWidget)
        self.gridLayout.setObjectName("gridLayout")
        self.gridLayout.setSizeConstraint(QLayout.SizeConstraint.SetNoConstraint)
        self.gridLayout.setHorizontalSpacing(8)
        self.gridLayout.setContentsMargins(0, 0, 0, 0)
        self.pushButton_5 = QPushButton(self.gridLayoutWidget)
        self.pushButton_5.setObjectName("pushButton_5")
        self.pushButton_5.setStyleSheet(
            "QPushButton{\n"
            "    background-color: rgb(167, 255, 200);  /* Bluish background */\n"
            "    color: rgb(148, 0, 111);               /* Font color for the text */\n"
            '    font: bold 8pt "MS Shell Dlg 2";\n'
            "    padding: 5px;\n"
            "    border-radius: 5px;                   /* Rounded corners */\n"
            "    border: 2px solid rgb(85, 0, 127);           \n"
            "}"
        )

        self.gridLayout.addWidget(self.pushButton_5, 12, 3, 1, 1)

        self.text_11 = QLabel(self.gridLayoutWidget)
        self.text_11.setObjectName("text_11")
        self.text_11.setStyleSheet(
            "QLabel#text_11{\n"
            "background-color: rgb(255, 204, 255);\n"
            "color: black;               \n"
            'font: 12pt  "Arial Narrow";\n'
            " font-weight: normal;\n"
            "}"
        )

        self.gridLayout.addWidget(self.text_11, 6, 5, 1, 1)

        self.text_12 = QLabel(self.gridLayoutWidget)
        self.text_12.setObjectName("text_12")
        self.text_12.setStyleSheet(
            "\n"
            "QLabel#text_12{\n"
            "background-color: rgb(255, 204, 255);\n"
            "color: black;                /* Font color */\n"
            'font: 12pt  "Arial Narrow";\n'
            " font-weight: normal;\n"
            "}"
        )

        self.gridLayout.addWidget(self.text_12, 5, 5, 1, 1)

        self.pushButton_3 = QPushButton(self.gridLayoutWidget)
        self.pushButton_3.setObjectName("pushButton_3")
        sizePolicy1 = QSizePolicy(
            QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Preferred
        )
        sizePolicy1.setHorizontalStretch(0)
        sizePolicy1.setVerticalStretch(0)
        sizePolicy1.setHeightForWidth(
            self.pushButton_3.sizePolicy().hasHeightForWidth()
        )
        self.pushButton_3.setSizePolicy(sizePolicy1)
        self.pushButton_3.setStyleSheet(
            "QPushButton{\n"
            "    background-color: rgb(167, 255, 200);  /* Bluish background */\n"
            "    color: rgb(148, 0, 111);               /* Font color for the text */\n"
            '    font: bold 8pt "MS Shell Dlg 2";\n'
            "    padding: 5px;\n"
            "    border-radius: 5px;                   /* Rounded corners */\n"
            "    border: 2px solid rgb(85, 0, 127);           \n"
            "}"
        )

        self.gridLayout.addWidget(self.pushButton_3, 10, 3, 1, 1)

        self.lineEdit_6 = QLineEdit(self.gridLayoutWidget)
        self.lineEdit_6.setObjectName("lineEdit_6")
        sizePolicy1.setHeightForWidth(self.lineEdit_6.sizePolicy().hasHeightForWidth())
        self.lineEdit_6.setSizePolicy(sizePolicy1)
        self.lineEdit_6.setStyleSheet(
            "QLineEdit#lineEdit_6{\n"
            "background-color: #ffffff;\n"
            "border: 2px solid #000;\n"
            "border-radius: 6px;                   /* Rounded corners */\n"
            "  \n"
            "}"
        )

        self.gridLayout.addWidget(self.lineEdit_6, 4, 7, 1, 1)

        self.text_4 = QLabel(self.gridLayoutWidget)
        self.text_4.setObjectName("text_4")
        self.text_4.setStyleSheet(
            "\n"
            "QLabel#text_4{\n"
            " background-color: rgb(255, 204, 255);\n"
            "color: black;                /* Font color */\n"
            'font: 17pt  "Arial Narrow";\n'
            " font-weight: normal;\n"
            "}"
        )

        self.gridLayout.addWidget(self.text_4, 9, 2, 1, 1)

        self.pushButton = QPushButton(self.gridLayoutWidget)
        self.pushButton.setObjectName("pushButton")
        sizePolicy1.setHeightForWidth(self.pushButton.sizePolicy().hasHeightForWidth())
        self.pushButton.setSizePolicy(sizePolicy1)
        self.pushButton.setStyleSheet(
            "QPushButton{\n"
            "    background-color: rgb(167, 255, 200);  /* Bluish background */\n"
            "    color: rgb(148, 0, 111);               /* Font color for the text */\n"
            '    font: bold 8pt "MS Shell Dlg 2";\n'
            "    padding: 5px;\n"
            "    border-radius: 5px;                   /* Rounded corners */\n"
            "    border: 2px solid rgb(85, 0, 127);           \n"
            "}"
        )

        self.gridLayout.addWidget(self.pushButton, 4, 3, 1, 1)

        self.text_10 = QLabel(self.gridLayoutWidget)
        self.text_10.setObjectName("text_10")
        self.text_10.setStyleSheet(
            "\n"
            "QLabel#text_10{\n"
            "background-color: rgb(255, 204, 255);\n"
            "color: black;                /* Font color */\n"
            'font: 12pt  "Arial Narrow";\n'
            " font-weight: normal;\n"
            "}"
        )

        self.gridLayout.addWidget(self.text_10, 3, 7, 1, 1)

        self.text_3 = QLabel(self.gridLayoutWidget)
        self.text_3.setObjectName("text_3")
        self.text_3.setStyleSheet(
            "\n"
            "QLabel#text_3{\n"
            " background-color: rgb(255, 204, 255);\n"
            "color: black;                /* Font color */\n"
            'font: 17pt  "Arial Narrow";\n'
            " font-weight: normal;\n"
            "}"
        )

        self.gridLayout.addWidget(self.text_3, 6, 2, 1, 1)

        self.text_7 = QLabel(self.gridLayoutWidget)
        self.text_7.setObjectName("text_7")
        self.text_7.setStyleSheet(
            "\n"
            "QLabel#text_7{\n"
            "background-color: rgb(255, 204, 255);\n"
            "color: black;                /* Font color */\n"
            'font: 12pt  "Arial Narrow";\n'
            " font-weight: normal;\n"
            "}"
        )

        self.gridLayout.addWidget(self.text_7, 2, 5, 1, 1)

        self.lineEdit_4 = QLineEdit(self.gridLayoutWidget)
        self.lineEdit_4.setObjectName("lineEdit_4")
        sizePolicy1.setHeightForWidth(self.lineEdit_4.sizePolicy().hasHeightForWidth())
        self.lineEdit_4.setSizePolicy(sizePolicy1)
        self.lineEdit_4.setStyleSheet(
            "QLineEdit#lineEdit_4{\n"
            "background-color: #ffffff;\n"
            "border: 2px solid #000;\n"
            "border-radius: 6px;                   /* Rounded corners */\n"
            "  \n"
            "}"
        )

        self.gridLayout.addWidget(self.lineEdit_4, 4, 5, 1, 1)

        self.tmf_input_file_path = QLineEdit(self.gridLayoutWidget)
        self.tmf_input_file_path.setObjectName("tmf_input_file_path")
        sizePolicy2 = QSizePolicy(
            QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred
        )
        sizePolicy2.setHorizontalStretch(0)
        sizePolicy2.setVerticalStretch(0)
        sizePolicy2.setHeightForWidth(
            self.tmf_input_file_path.sizePolicy().hasHeightForWidth()
        )
        self.tmf_input_file_path.setSizePolicy(sizePolicy2)
        self.tmf_input_file_path.setStyleSheet(
            "QLineEdit {\n"
            "    background-color: #ffffff;\n"
            "    border: 2px solid #000;\n"
            "}"
        )

        self.gridLayout.addWidget(self.tmf_input_file_path, 10, 2, 1, 1)

        self.text_2 = QLabel(self.gridLayoutWidget)
        self.text_2.setObjectName("text_2")
        sizePolicy3 = QSizePolicy(
            QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed
        )
        sizePolicy3.setHorizontalStretch(0)
        sizePolicy3.setVerticalStretch(0)
        sizePolicy3.setHeightForWidth(self.text_2.sizePolicy().hasHeightForWidth())
        self.text_2.setSizePolicy(sizePolicy3)
        self.text_2.setStyleSheet(
            "\n"
            "QLabel#text_2{\n"
            " background-color: rgb(255, 204, 255);\n"
            "color: black;                /* Font color */\n"
            'font: 17pt  "Arial Narrow";\n'
            " font-weight: normal;\n"
            "}"
        )

        self.gridLayout.addWidget(self.text_2, 3, 2, 1, 1)

        self.horizontalSpacer_2 = QSpacerItem(
            40, 20, QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Minimum
        )

        self.gridLayout.addItem(self.horizontalSpacer_2, 4, 6, 1, 1)

        self.text_14 = QLabel(self.gridLayoutWidget)
        self.text_14.setObjectName("text_14")
        self.text_14.setStyleSheet(
            "QLabel#text_14{\n"
            "background-color: rgb(255, 204, 255);\n"
            "color: black;                /* Font color */\n"
            'font: 12pt  "Arial Narrow";\n'
            " font-weight: normal;\n"
            "}"
        )

        self.gridLayout.addWidget(self.text_14, 6, 7, 1, 1)

        self.text_13 = QLabel(self.gridLayoutWidget)
        self.text_13.setObjectName("text_13")
        self.text_13.setStyleSheet(
            "QLabel#text_13{\n"
            "background-color: rgb(255, 204, 255);\n"
            "color: black;              \n"
            'font: 12pt  "Arial Narrow";\n'
            " font-weight: normal;\n"
            "}"
        )

        self.gridLayout.addWidget(self.text_13, 5, 7, 1, 1)

        self.lineEdit_5 = QLineEdit(self.gridLayoutWidget)
        self.lineEdit_5.setObjectName("lineEdit_5")
        sizePolicy1.setHeightForWidth(self.lineEdit_5.sizePolicy().hasHeightForWidth())
        self.lineEdit_5.setSizePolicy(sizePolicy1)
        self.lineEdit_5.setStyleSheet(
            "QLineEdit#lineEdit_5{\n"
            "background-color: #ffffff;\n"
            "border: 2px solid #000;\n"
            "border-radius: 6px;                   /* Rounded corners */\n"
            "  \n"
            "}"
        )

        self.gridLayout.addWidget(self.lineEdit_5, 7, 5, 1, 1)

        self.verticalSpacer_2 = QSpacerItem(
            20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding
        )

        self.gridLayout.addItem(self.verticalSpacer_2, 11, 3, 1, 1)

        self.local_xml_path = QLineEdit(self.gridLayoutWidget)
        self.local_xml_path.setObjectName("local_xml_path")
        sizePolicy2.setHeightForWidth(
            self.local_xml_path.sizePolicy().hasHeightForWidth()
        )
        self.local_xml_path.setSizePolicy(sizePolicy2)
        self.local_xml_path.setStyleSheet(
            "QLineEdit {\n"
            "    background-color: #ffffff;\n"
            "    border: 2px solid #000;\n"
            "}"
        )

        self.gridLayout.addWidget(self.local_xml_path, 4, 2, 1, 1)

        self.global_xml_path = QLineEdit(self.gridLayoutWidget)
        self.global_xml_path.setObjectName("global_xml_path")
        sizePolicy2.setHeightForWidth(
            self.global_xml_path.sizePolicy().hasHeightForWidth()
        )
        self.global_xml_path.setSizePolicy(sizePolicy2)
        self.global_xml_path.setStyleSheet(
            "QLineEdit {\n"
            "    background-color: #ffffff;\n"
            "    border: 2px solid #000;\n"
            "}"
        )

        self.gridLayout.addWidget(self.global_xml_path, 7, 2, 1, 1)

        self.horizontalSpacer_4 = QSpacerItem(
            40, 20, QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Minimum
        )

        self.gridLayout.addItem(self.horizontalSpacer_4, 7, 4, 1, 1)

        self.pushButton_2 = QPushButton(self.gridLayoutWidget)
        self.pushButton_2.setObjectName("pushButton_2")
        sizePolicy1.setHeightForWidth(
            self.pushButton_2.sizePolicy().hasHeightForWidth()
        )
        self.pushButton_2.setSizePolicy(sizePolicy1)
        self.pushButton_2.setStyleSheet(
            "QPushButton{\n"
            "    background-color: rgb(167, 255, 200);  /* Bluish background */\n"
            "    color: rgb(148, 0, 111);               /* Font color for the text */\n"
            '    font: bold 8pt "MS Shell Dlg 2";\n'
            "    padding: 5px;\n"
            "    border-radius: 5px;                   /* Rounded corners */\n"
            "    border: 2px solid rgb(85, 0, 127);           \n"
            "}"
        )

        self.gridLayout.addWidget(self.pushButton_2, 7, 3, 1, 1)

        self.text_6 = QLabel(self.gridLayoutWidget)
        self.text_6.setObjectName("text_6")
        self.text_6.setStyleSheet(
            "\n"
            "QLabel#text_6\n"
            "{\n"
            " background-color: rgb(255, 204, 255);\n"
            "color: black;                /* Font color */\n"
            'font: 17pt  "Arial Narrow";\n'
            " font-weight: normal;\n"
            "}"
        )

        self.gridLayout.addWidget(self.text_6, 12, 2, 1, 1)

        self.text_9 = QLabel(self.gridLayoutWidget)
        self.text_9.setObjectName("text_9")
        self.text_9.setStyleSheet(
            "\n"
            "QLabel#text_9{\n"
            "background-color: rgb(255, 204, 255);\n"
            "color: black;                /* Font color */\n"
            'font: 12pt  "Arial Narrow";\n'
            " font-weight: normal;\n"
            "}"
        )

        self.gridLayout.addWidget(self.text_9, 2, 7, 1, 1)

        self.text_8 = QLabel(self.gridLayoutWidget)
        self.text_8.setObjectName("text_8")
        self.text_8.setStyleSheet(
            "\n"
            "QLabel#text_8{\n"
            "background-color: rgb(255, 204, 255);\n"
            "color: black;                /* Font color */\n"
            'font: 12pt  "Arial Narrow";\n'
            " font-weight: normal;\n"
            "}"
        )

        self.gridLayout.addWidget(self.text_8, 3, 5, 1, 1)

        self.horizontalSpacer_3 = QSpacerItem(
            40, 20, QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Minimum
        )

        self.gridLayout.addItem(self.horizontalSpacer_3, 4, 4, 1, 1)

        self.verticalSpacer_4 = QSpacerItem(
            20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding
        )

        self.gridLayout.addItem(self.verticalSpacer_4, 13, 3, 1, 1)

        self.lineEdit_7 = QLineEdit(self.gridLayoutWidget)
        self.lineEdit_7.setObjectName("lineEdit_7")
        sizePolicy1.setHeightForWidth(self.lineEdit_7.sizePolicy().hasHeightForWidth())
        self.lineEdit_7.setSizePolicy(sizePolicy1)
        self.lineEdit_7.setStyleSheet(
            "QLineEdit#lineEdit_7{\n"
            "background-color: #ffffff;\n"
            "border: 2px solid #000;\n"
            "border-radius: 6px;                   /* Rounded corners */\n"
            "  \n"
            "}"
        )

        self.gridLayout.addWidget(self.lineEdit_7, 7, 7, 1, 1)

        self.text_16 = QLabel(self.gridLayoutWidget)
        self.text_16.setObjectName("text_16")
        self.text_16.setStyleSheet(
            "\n"
            "QLabel#text_16{\n"
            " background-color: rgb(255, 204, 255);\n"
            "color: black;                /* Font color */\n"
            'font: 17pt  "Arial Narrow";\n'
            " font-weight: normal;\n"
            "}"
        )

        self.gridLayout.addWidget(self.text_16, 14, 2, 1, 1)

        self.pushButton_6 = QPushButton(self.gridLayoutWidget)
        self.pushButton_6.setObjectName("pushButton_6")
        self.pushButton_6.setStyleSheet(
            "QPushButton{\n"
            "    background-color: rgb(167, 255, 200);  /* Bluish background */\n"
            "    color: rgb(148, 0, 111);               /* Font color for the text */\n"
            '    font: bold 8pt "MS Shell Dlg 2";\n'
            "    padding: 5px;\n"
            "    border-radius: 5px;                   /* Rounded corners */\n"
            "    border: 2px solid rgb(85, 0, 127);           \n"
            "}"
        )

        self.gridLayout.addWidget(self.pushButton_6, 14, 3, 1, 1)

        self.verticalSpacer_5 = QSpacerItem(
            20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding
        )

        self.gridLayout.addItem(self.verticalSpacer_5, 8, 2, 1, 1)

        self.textBrowser = QTextBrowser(self.tab)
        self.textBrowser.setObjectName("textBrowser")
        self.textBrowser.setGeometry(QRect(30, 590, 701, 121))
        self.textBrowser.setStyleSheet(
            "QTextBrowser#textBrowser{\n" " background-color: white;\n" "}\n" "\n" ""
        )
        self.tabWidget.addTab(self.tab, "")
        self.tab_2 = QWidget()
        self.tab_2.setObjectName("tab_2")
        self.formLayoutWidget = QWidget(self.tab_2)
        self.formLayoutWidget.setObjectName("formLayoutWidget")
        self.formLayoutWidget.setGeometry(QRect(20, 20, 551, 101))
        self.formLayout = QFormLayout(self.formLayoutWidget)
        self.formLayout.setObjectName("formLayout")
        self.formLayout.setSizeConstraint(QLayout.SizeConstraint.SetDefaultConstraint)
        self.formLayout.setContentsMargins(0, 0, 0, 0)
        self.Number_label_2 = QLabel(self.formLayoutWidget)
        self.Number_label_2.setObjectName("Number_label_2")
        sizePolicy.setHeightForWidth(
            self.Number_label_2.sizePolicy().hasHeightForWidth()
        )
        self.Number_label_2.setSizePolicy(sizePolicy)
        self.Number_label_2.setLayoutDirection(Qt.LayoutDirection.RightToLeft)
        self.Number_label_2.setStyleSheet(
            "/* Title Label Style */\n"
            "QLabel#Number_label_2{\n"
            "    background-color:rgb(44, 120, 127);  /* Bluish background */\n"
            "    color: white;               /* Font color for the text */\n"
            '    font: 14pt "MS Shell Dlg 2";\n'
            "    padding: 5px;\n"
            "    border-radius: 10px;                   /* Rounded corners */\n"
            "    border: 2px solid rgb(85, 0, 127);           \n"
            "}\n"
            ""
        )

        self.formLayout.setWidget(0, QFormLayout.LabelRole, self.Number_label_2)

        self.text_5 = QLabel(self.formLayoutWidget)
        self.text_5.setObjectName("text_5")
        sizePolicy.setHeightForWidth(self.text_5.sizePolicy().hasHeightForWidth())
        self.text_5.setSizePolicy(sizePolicy)
        self.text_5.setLayoutDirection(Qt.LayoutDirection.LeftToRight)
        self.text_5.setStyleSheet(
            "\n"
            "QLabel#text_5{\n"
            " background-color: rgb(255, 204, 255);\n"
            "color: black;                /* Font color */\n"
            'font: bold 17pt "Arial Narrow";\n'
            " font-weight: normal;\n"
            "}\n"
            "\n"
            ""
        )

        self.formLayout.setWidget(0, QFormLayout.FieldRole, self.text_5)

        self.label = QLabel(self.formLayoutWidget)
        self.label.setObjectName("label")
        self.label.setStyleSheet(
            "\n"
            "QLabel#label{\n"
            " background-color: rgb(255, 204, 255);\n"
            "color: black;                /* Font color */\n"
            'font: bold 17pt "Arial Narrow";\n'
            " font-weight: normal;\n"
            "}\n"
            ""
        )

        self.formLayout.setWidget(1, QFormLayout.FieldRole, self.label)

        self.horizontalLayoutWidget_2 = QWidget(self.tab_2)
        self.horizontalLayoutWidget_2.setObjectName("horizontalLayoutWidget_2")
        self.horizontalLayoutWidget_2.setGeometry(QRect(20, 280, 451, 41))
        self.horizontalLayout_2 = QHBoxLayout(self.horizontalLayoutWidget_2)
        self.horizontalLayout_2.setObjectName("horizontalLayout_2")
        self.horizontalLayout_2.setContentsMargins(0, 0, 0, 0)
        self.xml_file_mmpa = QLineEdit(self.horizontalLayoutWidget_2)
        self.xml_file_mmpa.setObjectName("xml_file_mmpa")
        sizePolicy2.setHeightForWidth(
            self.xml_file_mmpa.sizePolicy().hasHeightForWidth()
        )
        self.xml_file_mmpa.setSizePolicy(sizePolicy2)
        self.xml_file_mmpa.setStyleSheet(
            "QLineEdit {\n"
            "    background-color: #ffffff;\n"
            "    border: 2px solid #000;\n"
            "}"
        )

        self.horizontalLayout_2.addWidget(self.xml_file_mmpa)

        self.pushButton_4 = QPushButton(self.horizontalLayoutWidget_2)
        self.pushButton_4.setObjectName("pushButton_4")
        sizePolicy1.setHeightForWidth(
            self.pushButton_4.sizePolicy().hasHeightForWidth()
        )
        self.pushButton_4.setSizePolicy(sizePolicy1)
        self.pushButton_4.setStyleSheet(
            "QPushButton{\n"
            "    background-color: rgb(167, 255, 200);  /* Bluish background */\n"
            "    color: rgb(148, 0, 111);               /* Font color for the text */\n"
            '    font: bold 8pt "MS Shell Dlg 2";\n'
            "    padding: 5px;\n"
            "    border-radius: 5px;                   /* Rounded corners */\n"
            "    border: 2px solid rgb(85, 0, 127);           \n"
            "}"
        )

        self.horizontalLayout_2.addWidget(self.pushButton_4)

        self.text_15 = QLabel(self.tab_2)
        self.text_15.setObjectName("text_15")
        self.text_15.setGeometry(QRect(30, 230, 251, 33))
        sizePolicy.setHeightForWidth(self.text_15.sizePolicy().hasHeightForWidth())
        self.text_15.setSizePolicy(sizePolicy)
        self.text_15.setLayoutDirection(Qt.LayoutDirection.LeftToRight)
        self.text_15.setStyleSheet(
            "\n"
            "QLabel#text_15{\n"
            " background-color: rgb(255, 204, 255);\n"
            "color: black;                /* Font color */\n"
            'font: bold 17pt "Arial Narrow";\n'
            " font-weight: normal;\n"
            "}\n"
            "\n"
            ""
        )
        self.verticalLayoutWidget = QWidget(self.tab_2)
        self.verticalLayoutWidget.setObjectName("verticalLayoutWidget")
        self.verticalLayoutWidget.setGeometry(QRect(20, 130, 551, 51))
        self.verticalLayout = QVBoxLayout(self.verticalLayoutWidget)
        self.verticalLayout.setObjectName("verticalLayout")
        self.verticalLayout.setContentsMargins(0, 0, 0, 0)
        self.label_2 = QLabel(self.verticalLayoutWidget)
        self.label_2.setObjectName("label_2")
        self.label_2.setStyleSheet(
            "\n"
            "QLabel#label_2{\n"
            " background-color: rgb(255, 204, 255);\n"
            "color: black;                /* Font color */\n"
            'font: 12pt "Arial Narrow";\n'
            " font-weight: normal;\n"
            "}\n"
            ""
        )

        self.verticalLayout.addWidget(self.label_2)

        self.label_3 = QLabel(self.tab_2)
        self.label_3.setObjectName("label_3")
        self.label_3.setGeometry(QRect(20, 330, 441, 61))
        self.label_3.setStyleSheet(
            "\n"
            "QLabel#label_3{\n"
            " background-color: rgb(255, 204, 255);\n"
            "color: black;                /* Font color */\n"
            'font: bold 17pt "Arial Narrow";\n'
            " font-weight: normal;\n"
            "}\n"
            ""
        )
        self.verticalLayoutWidget_2 = QWidget(self.tab_2)
        self.verticalLayoutWidget_2.setObjectName("verticalLayoutWidget_2")
        self.verticalLayoutWidget_2.setGeometry(QRect(20, 380, 431, 199))
        self.verticalLayout_2 = QVBoxLayout(self.verticalLayoutWidget_2)
        self.verticalLayout_2.setObjectName("verticalLayout_2")
        self.verticalLayout_2.setContentsMargins(0, 0, 0, 0)
        self.checkBox_1 = QCheckBox(self.verticalLayoutWidget_2)
        self.checkBox_1.setObjectName("checkBox_1")
        self.checkBox_1.setStyleSheet(
            "\n"
            "\n"
            "QCheckBox#checkBox_1 {\n"
            "    background-color: rgb(255, 204, 255); \n"
            "    color: black;                       \n"
            '    font: normal 17pt "Arial Narrow";   \n'
            "}\n"
            "\n"
            "QCheckBox#checkBox_1::indicator {\n"
            "background-color: white; \n"
            "    width: 40px; \n"
            "    height: 40px; \n"
            "}\n"
            "\n"
            "QCheckBox#checkBox_1::indicator:unchecked {\n"
            '    image: url("C:/Users/Lipika Dudeja/Downloads/unchecked.svg"); \n'
            "}\n"
            "\n"
            "QCheckBox#checkBox_1::indicator:checked {\n"
            '    image: url("C:/Users/Lipika Dudeja/Downloads/checked.svg"); \n'
            "}"
        )

        self.verticalLayout_2.addWidget(self.checkBox_1)

        self.checkBox_2 = QCheckBox(self.verticalLayoutWidget_2)
        self.checkBox_2.setObjectName("checkBox_2")
        self.checkBox_2.setStyleSheet(
            "QCheckBox#checkBox_2 {\n"
            "    background-color: rgb(255, 204, 255); \n"
            "    color: black;                       \n"
            '    font: normal 17pt "Arial Narrow";   \n'
            "}\n"
            "\n"
            "QCheckBox#checkBox_2::indicator {\n"
            "background-color: white; \n"
            "    width: 40px; \n"
            "    height: 40px; \n"
            "}\n"
            "\n"
            "QCheckBox#checkBox_2::indicator:unchecked {\n"
            '    image: url("C:/Users/Lipika Dudeja/Downloads/unchecked.svg"); \n'
            "}\n"
            "\n"
            "QCheckBox#checkBox_2::indicator:checked {\n"
            '    image: url("C:/Users/Lipika Dudeja/Downloads/checked.svg"); \n'
            "}\n"
            ""
        )

        self.verticalLayout_2.addWidget(self.checkBox_2)

        self.checkBox_3 = QCheckBox(self.verticalLayoutWidget_2)
        self.checkBox_3.setObjectName("checkBox_3")
        self.checkBox_3.setStyleSheet(
            "QCheckBox#checkBox_3 {\n"
            "    background-color: rgb(255, 204, 255); \n"
            "    color: black;                       \n"
            '    font: normal 17pt "Arial Narrow";   \n'
            "}\n"
            "\n"
            "QCheckBox#checkBox_3::indicator {\n"
            "background-color: white; \n"
            "    width: 40px; \n"
            "    height: 40px; \n"
            "}\n"
            "\n"
            "QCheckBox#checkBox_3::indicator:unchecked {\n"
            '    image: url("C:/Users/Lipika Dudeja/Downloads/unchecked.svg"); \n'
            "}\n"
            "\n"
            "QCheckBox#checkBox_3::indicator:checked {\n"
            '    image: url("C:/Users/Lipika Dudeja/Downloads/checked.svg"); \n'
            "}\n"
            ""
        )

        self.verticalLayout_2.addWidget(self.checkBox_3)

        self.checkBox_4 = QCheckBox(self.verticalLayoutWidget_2)
        self.checkBox_4.setObjectName("checkBox_4")
        self.checkBox_4.setStyleSheet(
            "QCheckBox#checkBox_4{\n"
            "    background-color: rgb(255, 204, 255); \n"
            "    color: black;                       \n"
            '    font: normal 17pt "Arial Narrow";   \n'
            "}\n"
            "\n"
            "QCheckBox#checkBox_4::indicator {\n"
            "background-color: white; \n"
            "    width: 40px; \n"
            "    height: 40px; \n"
            "}\n"
            "\n"
            "QCheckBox#checkBox_4::indicator:unchecked {\n"
            '    image: url("C:/Users/Lipika Dudeja/Downloads/unchecked.svg"); \n'
            "}\n"
            "\n"
            "QCheckBox#checkBox_4::indicator:checked {\n"
            '    image: url("C:/Users/Lipika Dudeja/Downloads/checked.svg"); \n'
            "}"
        )

        self.verticalLayout_2.addWidget(self.checkBox_4)

        self.textBrowser_2 = QTextBrowser(self.tab_2)
        self.textBrowser_2.setObjectName("textBrowser_2")
        self.textBrowser_2.setGeometry(QRect(370, 730, 751, 121))
        self.textBrowser_2.setStyleSheet(
            "QTextBrowser#textBrowser{\n" " background-color: white;\n" "}\n" "\n" ""
        )
        self.textBrowser_3 = QTextBrowser(self.tab_2)
        self.textBrowser_3.setObjectName("textBrowser_3")
        self.textBrowser_3.setGeometry(QRect(30, 590, 701, 121))
        self.textBrowser_3.setStyleSheet(
            "QTextBrowser#textBrowser_3{\n" " background-color: white;\n" "}\n" "\n" ""
        )
        self.tabWidget.addTab(self.tab_2, "")
        self.progressBar = QProgressBar(self.centralwidget)
        self.progressBar.setObjectName("progressBar")
        self.progressBar.setGeometry(QRect(10, 780, 781, 23))
        self.progressBar.setValue(24)
        MainWindow.setCentralWidget(self.centralwidget)

        self.retranslateUi(MainWindow)

        self.tabWidget.setCurrentIndex(0)

        QMetaObject.connectSlotsByName(MainWindow)

    # setupUi

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(
            QCoreApplication.translate("MainWindow", "MainWindow", None)
        )
        self.Number_label.setText(QCoreApplication.translate("MainWindow", " 1", None))
        self.text.setText(
            QCoreApplication.translate(
                "MainWindow",
                "Scale the Stresses and Modify the Temperature      ",
                None,
            )
        )
        self.pushButton_5.setText(
            QCoreApplication.translate("MainWindow", "Submit", None)
        )
        self.text_11.setText(
            QCoreApplication.translate("MainWindow", "Multiplier", None)
        )
        self.text_12.setText(QCoreApplication.translate("MainWindow", "Stress", None))
        self.pushButton_3.setText(
            QCoreApplication.translate("MainWindow", "Browse", None)
        )
        self.text_4.setText(
            QCoreApplication.translate(
                "MainWindow", "TMF Input file (Required for TMF)", None
            )
        )
        self.pushButton.setText(
            QCoreApplication.translate("MainWindow", "Browse", None)
        )
        self.text_10.setText(QCoreApplication.translate("MainWindow", "Adder", None))
        self.text_3.setText(
            QCoreApplication.translate("MainWindow", "Global xml file", None)
        )
        self.text_7.setText(QCoreApplication.translate("MainWindow", "Stress", None))
        self.text_2.setText(
            QCoreApplication.translate("MainWindow", "Local xml file", None)
        )
        self.text_14.setText(QCoreApplication.translate("MainWindow", "Adder", None))
        self.text_13.setText(QCoreApplication.translate("MainWindow", "Temp", None))
        self.pushButton_2.setText(
            QCoreApplication.translate("MainWindow", "Browse", None)
        )
        self.text_6.setText(
            QCoreApplication.translate(
                "MainWindow", "Merge Local xml into Global xml", None
            )
        )
        self.text_9.setText(QCoreApplication.translate("MainWindow", "Temp", None))
        self.text_8.setText(
            QCoreApplication.translate("MainWindow", "Multiplier", None)
        )
        self.text_16.setText(
            QCoreApplication.translate(
                "MainWindow", "Local xml + Global xml & Run TMF", None
            )
        )
        self.pushButton_6.setText(
            QCoreApplication.translate("MainWindow", "Submit", None)
        )
        self.tabWidget.setTabText(
            self.tabWidget.indexOf(self.tab),
            QCoreApplication.translate("MainWindow", "Tab 1", None),
        )
        self.Number_label_2.setText(QCoreApplication.translate("MainWindow", "2", None))
        self.text_5.setText(
            QCoreApplication.translate(
                "MainWindow", "Convert xml file from M_MPa Unit ", None
            )
        )
        self.label.setText(
            QCoreApplication.translate(
                "MainWindow", "System to mm_MPa Unit System", None
            )
        )
        self.pushButton_4.setText(
            QCoreApplication.translate("MainWindow", "Browse", None)
        )
        self.text_15.setText(
            QCoreApplication.translate("MainWindow", "xml file in M MPa Unit", None)
        )
        self.label_2.setText(
            QCoreApplication.translate(
                "MainWindow",
                "Nodal coordinates scaled by 1.0E3, Nodal Stresses scaled by 1.0E-6",
                None,
            )
        )
        self.label_3.setText(
            QCoreApplication.translate(
                "MainWindow", "Select the box if the given xml file has :", None
            )
        )
        self.checkBox_1.setText(
            QCoreApplication.translate("MainWindow", "Nodal Temperature", None)
        )
        self.checkBox_2.setText(
            QCoreApplication.translate("MainWindow", "Nodal Coordinates", None)
        )
        self.checkBox_3.setText(
            QCoreApplication.translate("MainWindow", "Element Connectivities", None)
        )
        self.checkBox_4.setText(
            QCoreApplication.translate("MainWindow", "Nodal Stresses", None)
        )
        self.tabWidget.setTabText(
            self.tabWidget.indexOf(self.tab_2),
            QCoreApplication.translate("MainWindow", "Tab 2", None),
        )

    # retranslateUi
