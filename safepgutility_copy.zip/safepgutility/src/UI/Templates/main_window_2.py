# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'main_window_2.ui'
##
## Created by: Qt User Interface Compiler version 6.7.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QAction, QBrush, QColor, QConicalGradient,
    QCursor, QFont, QFontDatabase, QGradient,
    QIcon, QImage, QKeySequence, QLinearGradient,
    QPainter, QPalette, QPixmap, QRadialGradient,
    QTransform)
from PySide6.QtWidgets import (QApplication, QCheckBox, QFormLayout, QGridLayout,
    QHBoxLayout, QLabel, QLayout, QLineEdit,
    QMainWindow, QMenu, QMenuBar, QProgressBar,
    QPushButton, QSizePolicy, QSpacerItem, QTabWidget,
    QTextBrowser, QVBoxLayout, QWidget)

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        if not MainWindow.objectName():
            MainWindow.setObjectName(u"MainWindow")
        MainWindow.setEnabled(True)
        MainWindow.resize(1264, 872)
        self.actionOpen = QAction(MainWindow)
        self.actionOpen.setObjectName(u"actionOpen")
        self.actionSave = QAction(MainWindow)
        self.actionSave.setObjectName(u"actionSave")
        self.actionSave_As = QAction(MainWindow)
        self.actionSave_As.setObjectName(u"actionSave_As")
        self.centralwidget = QWidget(MainWindow)
        self.centralwidget.setObjectName(u"centralwidget")
        self.gridLayoutWidget_2 = QWidget(self.centralwidget)
        self.gridLayoutWidget_2.setObjectName(u"gridLayoutWidget_2")
        self.gridLayoutWidget_2.setGeometry(QRect(0, 0, 1251, 821))
        self.gridLayout_2 = QGridLayout(self.gridLayoutWidget_2)
        self.gridLayout_2.setObjectName(u"gridLayout_2")
        self.gridLayout_2.setSizeConstraint(QLayout.SetDefaultConstraint)
        self.gridLayout_2.setHorizontalSpacing(8)
        self.gridLayout_2.setContentsMargins(0, 0, 0, 0)
        self.verticalLayout_5 = QVBoxLayout()
        self.verticalLayout_5.setObjectName(u"verticalLayout_5")
        self.verticalSpacer = QSpacerItem(20, 24, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Fixed)

        self.verticalLayout_5.addItem(self.verticalSpacer)

        self.textBrowser = QTextBrowser(self.gridLayoutWidget_2)
        self.textBrowser.setObjectName(u"textBrowser")

        self.verticalLayout_5.addWidget(self.textBrowser)

        self.textBrowser_22 = QTextBrowser(self.gridLayoutWidget_2)
        self.textBrowser_22.setObjectName(u"textBrowser_22")

        self.verticalLayout_5.addWidget(self.textBrowser_22)

        self.verticalSpacer_3 = QSpacerItem(20, 5, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Fixed)

        self.verticalLayout_5.addItem(self.verticalSpacer_3)


        self.gridLayout_2.addLayout(self.verticalLayout_5, 2, 1, 1, 1)

        self.tabWidget = QTabWidget(self.gridLayoutWidget_2)
        self.tabWidget.setObjectName(u"tabWidget")
        self.tabWidget.setSizeIncrement(QSize(0, 40))
        self.tabWidget.setStyleSheet(u"/* Main Window Style */\n"
"QWidget {\n"
"    background-color: rgb(255, 204, 255);  /* Pinkish background */\n"
"}")
        self.tab = QWidget()
        self.tab.setObjectName(u"tab")
        self.horizontalLayoutWidget = QWidget(self.tab)
        self.horizontalLayoutWidget.setObjectName(u"horizontalLayoutWidget")
        self.horizontalLayoutWidget.setGeometry(QRect(10, -1, 581, 44))
        self.horizontalLayout = QHBoxLayout(self.horizontalLayoutWidget)
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.horizontalLayout.setSizeConstraint(QLayout.SetDefaultConstraint)
        self.horizontalLayout.setContentsMargins(0, 0, 0, 0)
        self.Number_label = QLabel(self.horizontalLayoutWidget)
        self.Number_label.setObjectName(u"Number_label")
        sizePolicy = QSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.Number_label.sizePolicy().hasHeightForWidth())
        self.Number_label.setSizePolicy(sizePolicy)
        self.Number_label.setLayoutDirection(Qt.LeftToRight)
        self.Number_label.setStyleSheet(u"/* Title Label Style */\n"
"QLabel#Number_label {\n"
"    background-color:rgb(44, 120, 127);  /* Bluish background */\n"
"    color: white;               /* Font color for the text */\n"
"    font: 14pt \"MS Shell Dlg 2\";\n"
"    padding: 5px;\n"
"    border-radius: 10px;                   /* Rounded corners */\n"
"    border: 2px solid rgb(85, 0, 127);           \n"
"}\n"
"")

        self.horizontalLayout.addWidget(self.Number_label)

        self.text = QLabel(self.horizontalLayoutWidget)
        self.text.setObjectName(u"text")
        sizePolicy.setHeightForWidth(self.text.sizePolicy().hasHeightForWidth())
        self.text.setSizePolicy(sizePolicy)
        self.text.setLayoutDirection(Qt.LeftToRight)
        self.text.setStyleSheet(u"\n"
"QLabel#text{\n"
" background-color: rgb(255, 204, 255);\n"
"color: black;                /* Font color */\n"
"font: bold 17pt \"Arial Narrow\";\n"
" font-weight: normal;\n"
"}\n"
"\n"
"")

        self.horizontalLayout.addWidget(self.text)

        self.gridLayoutWidget = QWidget(self.tab)
        self.gridLayoutWidget.setObjectName(u"gridLayoutWidget")
        self.gridLayoutWidget.setGeometry(QRect(10, 60, 601, 441))
        self.gridLayout = QGridLayout(self.gridLayoutWidget)
        self.gridLayout.setObjectName(u"gridLayout")
        self.gridLayout.setSizeConstraint(QLayout.SetDefaultConstraint)
        self.gridLayout.setHorizontalSpacing(8)
        self.gridLayout.setContentsMargins(0, 0, 0, 0)
        self.pushButton_2 = QPushButton(self.gridLayoutWidget)
        self.pushButton_2.setObjectName(u"pushButton_2")
        sizePolicy1 = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Preferred)
        sizePolicy1.setHorizontalStretch(0)
        sizePolicy1.setVerticalStretch(0)
        sizePolicy1.setHeightForWidth(self.pushButton_2.sizePolicy().hasHeightForWidth())
        self.pushButton_2.setSizePolicy(sizePolicy1)
        self.pushButton_2.setStyleSheet(u"QPushButton{\n"
"    background-color: rgb(167, 255, 200);  /* Bluish background */\n"
"    color: rgb(148, 0, 111);               /* Font color for the text */\n"
"    font: bold 8pt \"MS Shell Dlg 2\";\n"
"    padding: 5px;\n"
"    border-radius: 5px;                   /* Rounded corners */\n"
"    border: 2px solid rgb(85, 0, 127);           \n"
"}")

        self.gridLayout.addWidget(self.pushButton_2, 7, 3, 1, 1)

        self.text_6 = QLabel(self.gridLayoutWidget)
        self.text_6.setObjectName(u"text_6")
        self.text_6.setStyleSheet(u"\n"
"QLabel#text_6\n"
"{\n"
" background-color: rgb(255, 204, 255);\n"
"color: black;                /* Font color */\n"
"font: 17pt  \"Arial Narrow\";\n"
" font-weight: normal;\n"
"}")

        self.gridLayout.addWidget(self.text_6, 12, 2, 1, 1)

        self.text_9 = QLabel(self.gridLayoutWidget)
        self.text_9.setObjectName(u"text_9")
        self.text_9.setStyleSheet(u"\n"
"QLabel#text_9{\n"
"background-color: rgb(255, 204, 255);\n"
"color: black;                /* Font color */\n"
"font: 12pt  \"Arial Narrow\";\n"
" font-weight: normal;\n"
"}")

        self.gridLayout.addWidget(self.text_9, 2, 5, 1, 1)

        self.verticalSpacer_4 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout.addItem(self.verticalSpacer_4, 13, 3, 1, 1)

        self.text_8 = QLabel(self.gridLayoutWidget)
        self.text_8.setObjectName(u"text_8")
        self.text_8.setStyleSheet(u"\n"
"QLabel#text_8{\n"
"background-color: rgb(255, 204, 255);\n"
"color: black;                /* Font color */\n"
"font: 12pt  \"Arial Narrow\";\n"
" font-weight: normal;\n"
"}")

        self.gridLayout.addWidget(self.text_8, 3, 4, 1, 1)

        self.verticalSpacer_5 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout.addItem(self.verticalSpacer_5, 8, 2, 1, 1)

        self.temp_adder_2 = QLineEdit(self.gridLayoutWidget)
        self.temp_adder_2.setObjectName(u"temp_adder_2")
        sizePolicy1.setHeightForWidth(self.temp_adder_2.sizePolicy().hasHeightForWidth())
        self.temp_adder_2.setSizePolicy(sizePolicy1)
        self.temp_adder_2.setStyleSheet(u"QLineEdit#temp_adder_2{\n"
"background-color: #ffffff;\n"
"border: 2px solid #000;\n"
"border-radius: 6px;                   /* Rounded corners */\n"
"  \n"
"}")

        self.gridLayout.addWidget(self.temp_adder_2, 7, 5, 1, 1)

        self.text_16 = QLabel(self.gridLayoutWidget)
        self.text_16.setObjectName(u"text_16")
        self.text_16.setStyleSheet(u"\n"
"QLabel#text_16{\n"
" background-color: rgb(255, 204, 255);\n"
"color: black;                /* Font color */\n"
"font: 17pt  \"Arial Narrow\";\n"
" font-weight: normal;\n"
"}")

        self.gridLayout.addWidget(self.text_16, 14, 2, 1, 1)

        self.pushButton_6 = QPushButton(self.gridLayoutWidget)
        self.pushButton_6.setObjectName(u"pushButton_6")
        self.pushButton_6.setStyleSheet(u"QPushButton{\n"
"    background-color: rgb(167, 255, 200);  /* Bluish background */\n"
"    color: rgb(148, 0, 111);               /* Font color for the text */\n"
"    font: bold 8pt \"MS Shell Dlg 2\";\n"
"    padding: 5px;\n"
"    border-radius: 5px;                   /* Rounded corners */\n"
"    border: 2px solid rgb(85, 0, 127);           \n"
"}")

        self.gridLayout.addWidget(self.pushButton_6, 14, 3, 1, 1)

        self.temp_adder_1 = QLineEdit(self.gridLayoutWidget)
        self.temp_adder_1.setObjectName(u"temp_adder_1")
        sizePolicy1.setHeightForWidth(self.temp_adder_1.sizePolicy().hasHeightForWidth())
        self.temp_adder_1.setSizePolicy(sizePolicy1)
        self.temp_adder_1.setStyleSheet(u"QLineEdit#temp_adder_1{\n"
"background-color: #ffffff;\n"
"border: 2px solid #000;\n"
"border-radius: 6px;                \n"
"  \n"
"}")

        self.gridLayout.addWidget(self.temp_adder_1, 4, 5, 1, 1)

        self.pushButton_3 = QPushButton(self.gridLayoutWidget)
        self.pushButton_3.setObjectName(u"pushButton_3")
        sizePolicy1.setHeightForWidth(self.pushButton_3.sizePolicy().hasHeightForWidth())
        self.pushButton_3.setSizePolicy(sizePolicy1)
        self.pushButton_3.setStyleSheet(u"QPushButton{\n"
"    background-color: rgb(167, 255, 200);  /* Bluish background */\n"
"    color: rgb(148, 0, 111);               /* Font color for the text */\n"
"    font: bold 8pt \"MS Shell Dlg 2\";\n"
"    padding: 5px;\n"
"    border-radius: 5px;                   /* Rounded corners */\n"
"    border: 2px solid rgb(85, 0, 127);           \n"
"}")

        self.gridLayout.addWidget(self.pushButton_3, 10, 3, 1, 1)

        self.text_4 = QLabel(self.gridLayoutWidget)
        self.text_4.setObjectName(u"text_4")
        self.text_4.setStyleSheet(u"\n"
"QLabel#text_4{\n"
" background-color: rgb(255, 204, 255);\n"
"color: black;                /* Font color */\n"
"font: 17pt  \"Arial Narrow\";\n"
" font-weight: normal;\n"
"}")

        self.gridLayout.addWidget(self.text_4, 9, 2, 1, 1)

        self.text_3 = QLabel(self.gridLayoutWidget)
        self.text_3.setObjectName(u"text_3")
        self.text_3.setStyleSheet(u"\n"
"QLabel#text_3{\n"
" background-color: rgb(255, 204, 255);\n"
"color: black;                /* Font color */\n"
"font: 17pt  \"Arial Narrow\";\n"
" font-weight: normal;\n"
"}")

        self.gridLayout.addWidget(self.text_3, 6, 2, 1, 1)

        self.pushButton = QPushButton(self.gridLayoutWidget)
        self.pushButton.setObjectName(u"pushButton")
        sizePolicy1.setHeightForWidth(self.pushButton.sizePolicy().hasHeightForWidth())
        self.pushButton.setSizePolicy(sizePolicy1)
        self.pushButton.setStyleSheet(u"QPushButton{\n"
"    background-color: rgb(167, 255, 200);  /* Bluish background */\n"
"    color: rgb(148, 0, 111);               /* Font color for the text */\n"
"    font: bold 8pt \"MS Shell Dlg 2\";\n"
"    padding: 5px;\n"
"    border-radius: 5px;                   /* Rounded corners */\n"
"    border: 2px solid rgb(85, 0, 127);           \n"
"}")

        self.gridLayout.addWidget(self.pushButton, 4, 3, 1, 1)

        self.text_10 = QLabel(self.gridLayoutWidget)
        self.text_10.setObjectName(u"text_10")
        self.text_10.setStyleSheet(u"\n"
"QLabel#text_10{\n"
"background-color: rgb(255, 204, 255);\n"
"color: black;                /* Font color */\n"
"font: 12pt  \"Arial Narrow\";\n"
" font-weight: normal;\n"
"}")

        self.gridLayout.addWidget(self.text_10, 3, 5, 1, 1)

        self.text_7 = QLabel(self.gridLayoutWidget)
        self.text_7.setObjectName(u"text_7")
        self.text_7.setStyleSheet(u"\n"
"QLabel#text_7{\n"
"background-color: rgb(255, 204, 255);\n"
"color: black;                /* Font color */\n"
"font: 12pt  \"Arial Narrow\";\n"
" font-weight: normal;\n"
"}")

        self.gridLayout.addWidget(self.text_7, 2, 4, 1, 1)

        self.tmf_input_file_path = QLineEdit(self.gridLayoutWidget)
        self.tmf_input_file_path.setObjectName(u"tmf_input_file_path")
        sizePolicy2 = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        sizePolicy2.setHorizontalStretch(0)
        sizePolicy2.setVerticalStretch(0)
        sizePolicy2.setHeightForWidth(self.tmf_input_file_path.sizePolicy().hasHeightForWidth())
        self.tmf_input_file_path.setSizePolicy(sizePolicy2)
        self.tmf_input_file_path.setStyleSheet(u"QLineEdit {\n"
"    background-color: #ffffff;\n"
"    border: 2px solid #000;\n"
"}")

        self.gridLayout.addWidget(self.tmf_input_file_path, 10, 2, 1, 1)

        self.stress_multiplier_1 = QLineEdit(self.gridLayoutWidget)
        self.stress_multiplier_1.setObjectName(u"stress_multiplier_1")
        self.stress_multiplier_1.setEnabled(False)
        sizePolicy1.setHeightForWidth(self.stress_multiplier_1.sizePolicy().hasHeightForWidth())
        self.stress_multiplier_1.setSizePolicy(sizePolicy1)
        self.stress_multiplier_1.setStyleSheet(u"QLineEdit#stress_multiplier_1{\n"
"background-color: #ffffff;\n"
"border: 2px solid #000;\n"
"border-radius: 6px;                   /* Rounded corners */\n"
"  \n"
"}")

        self.gridLayout.addWidget(self.stress_multiplier_1, 4, 4, 1, 1)

        self.text_14 = QLabel(self.gridLayoutWidget)
        self.text_14.setObjectName(u"text_14")
        self.text_14.setStyleSheet(u"QLabel#text_14{\n"
"background-color: rgb(255, 204, 255);\n"
"color: black;                /* Font color */\n"
"font: 12pt  \"Arial Narrow\";\n"
" font-weight: normal;\n"
"}")

        self.gridLayout.addWidget(self.text_14, 6, 5, 1, 1)

        self.text_2 = QLabel(self.gridLayoutWidget)
        self.text_2.setObjectName(u"text_2")
        sizePolicy3 = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        sizePolicy3.setHorizontalStretch(0)
        sizePolicy3.setVerticalStretch(0)
        sizePolicy3.setHeightForWidth(self.text_2.sizePolicy().hasHeightForWidth())
        self.text_2.setSizePolicy(sizePolicy3)
        self.text_2.setStyleSheet(u"\n"
"QLabel#text_2{\n"
" background-color: rgb(255, 204, 255);\n"
"color: black;                /* Font color */\n"
"font: 17pt  \"Arial Narrow\";\n"
" font-weight: normal;\n"
"}")

        self.gridLayout.addWidget(self.text_2, 3, 2, 1, 1)

        self.stress_multiplier_2 = QLineEdit(self.gridLayoutWidget)
        self.stress_multiplier_2.setObjectName(u"stress_multiplier_2")
        sizePolicy1.setHeightForWidth(self.stress_multiplier_2.sizePolicy().hasHeightForWidth())
        self.stress_multiplier_2.setSizePolicy(sizePolicy1)
        self.stress_multiplier_2.setStyleSheet(u"QLineEdit#stress_multiplier_2{\n"
"background-color: #ffffff;\n"
"border: 2px solid #000;\n"
"border-radius: 6px;                   /* Rounded corners */\n"
"  \n"
"}")

        self.gridLayout.addWidget(self.stress_multiplier_2, 7, 4, 1, 1)

        self.local_xml_path = QLineEdit(self.gridLayoutWidget)
        self.local_xml_path.setObjectName(u"local_xml_path")
        sizePolicy2.setHeightForWidth(self.local_xml_path.sizePolicy().hasHeightForWidth())
        self.local_xml_path.setSizePolicy(sizePolicy2)
        self.local_xml_path.setStyleSheet(u"QLineEdit {\n"
"    background-color: #ffffff;\n"
"    border: 2px solid #000;\n"
"}")

        self.gridLayout.addWidget(self.local_xml_path, 4, 2, 1, 1)

        self.verticalSpacer_2 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout.addItem(self.verticalSpacer_2, 11, 3, 1, 1)

        self.global_xml_path = QLineEdit(self.gridLayoutWidget)
        self.global_xml_path.setObjectName(u"global_xml_path")
        sizePolicy2.setHeightForWidth(self.global_xml_path.sizePolicy().hasHeightForWidth())
        self.global_xml_path.setSizePolicy(sizePolicy2)
        self.global_xml_path.setStyleSheet(u"QLineEdit {\n"
"    background-color: #ffffff;\n"
"    border: 2px solid #000;\n"
"}")

        self.gridLayout.addWidget(self.global_xml_path, 7, 2, 1, 1)

        self.text_13 = QLabel(self.gridLayoutWidget)
        self.text_13.setObjectName(u"text_13")
        self.text_13.setStyleSheet(u"QLabel#text_13{\n"
"background-color: rgb(255, 204, 255);\n"
"color: black;              \n"
"font: 12pt  \"Arial Narrow\";\n"
" font-weight: normal;\n"
"}")

        self.gridLayout.addWidget(self.text_13, 5, 5, 1, 1)

        self.pushButton_5 = QPushButton(self.gridLayoutWidget)
        self.pushButton_5.setObjectName(u"pushButton_5")
        self.pushButton_5.setStyleSheet(u"QPushButton{\n"
"    background-color: rgb(167, 255, 200);  /* Bluish background */\n"
"    color: rgb(148, 0, 111);               /* Font color for the text */\n"
"    font: bold 8pt \"MS Shell Dlg 2\";\n"
"    padding: 5px;\n"
"    border-radius: 5px;                   /* Rounded corners */\n"
"    border: 2px solid rgb(85, 0, 127);           \n"
"}")

        self.gridLayout.addWidget(self.pushButton_5, 12, 3, 1, 1)

        self.text_11 = QLabel(self.gridLayoutWidget)
        self.text_11.setObjectName(u"text_11")
        self.text_11.setStyleSheet(u"QLabel#text_11{\n"
"background-color: rgb(255, 204, 255);\n"
"color: black;               \n"
"font: 12pt  \"Arial Narrow\";\n"
" font-weight: normal;\n"
"}")

        self.gridLayout.addWidget(self.text_11, 6, 4, 1, 1)

        self.text_12 = QLabel(self.gridLayoutWidget)
        self.text_12.setObjectName(u"text_12")
        self.text_12.setStyleSheet(u"\n"
"QLabel#text_12{\n"
"background-color: rgb(255, 204, 255);\n"
"color: black;                /* Font color */\n"
"font: 12pt  \"Arial Narrow\";\n"
" font-weight: normal;\n"
"}")

        self.gridLayout.addWidget(self.text_12, 5, 4, 1, 1)

        self.progressBar = QProgressBar(self.tab)
        self.progressBar.setObjectName(u"progressBar")
        self.progressBar.setGeometry(QRect(20, 750, 621, 24))
        self.progressBar.setValue(24)
        self.label_4 = QLabel(self.tab)
        self.label_4.setObjectName(u"label_4")
        self.label_4.setGeometry(QRect(40, 520, 641, 221))
        self.label_4.setStyleSheet(u"")
        self.tabWidget.addTab(self.tab, "")
        self.tab_2 = QWidget()
        self.tab_2.setObjectName(u"tab_2")
        self.formLayoutWidget = QWidget(self.tab_2)
        self.formLayoutWidget.setObjectName(u"formLayoutWidget")
        self.formLayoutWidget.setGeometry(QRect(20, 10, 551, 101))
        self.formLayout = QFormLayout(self.formLayoutWidget)
        self.formLayout.setObjectName(u"formLayout")
        self.formLayout.setSizeConstraint(QLayout.SetDefaultConstraint)
        self.formLayout.setContentsMargins(0, 0, 0, 0)
        self.Number_label_2 = QLabel(self.formLayoutWidget)
        self.Number_label_2.setObjectName(u"Number_label_2")
        sizePolicy.setHeightForWidth(self.Number_label_2.sizePolicy().hasHeightForWidth())
        self.Number_label_2.setSizePolicy(sizePolicy)
        self.Number_label_2.setLayoutDirection(Qt.LeftToRight)
        self.Number_label_2.setStyleSheet(u"/* Title Label Style */\n"
"QLabel#Number_label_2{\n"
"    background-color:rgb(44, 120, 127);  /* Bluish background */\n"
"    color: white;               /* Font color for the text */\n"
"    font: 14pt \"MS Shell Dlg 2\";\n"
"    padding: 5px;\n"
"    border-radius: 10px;                   /* Rounded corners */\n"
"    border: 2px solid rgb(85, 0, 127);           \n"
"}\n"
"")

        self.formLayout.setWidget(0, QFormLayout.LabelRole, self.Number_label_2)

        self.text_5 = QLabel(self.formLayoutWidget)
        self.text_5.setObjectName(u"text_5")
        sizePolicy.setHeightForWidth(self.text_5.sizePolicy().hasHeightForWidth())
        self.text_5.setSizePolicy(sizePolicy)
        self.text_5.setLayoutDirection(Qt.LeftToRight)
        self.text_5.setStyleSheet(u"\n"
"QLabel#text_5{\n"
" background-color: rgb(255, 204, 255);\n"
"color: black;                /* Font color */\n"
"font: bold 17pt \"Arial Narrow\";\n"
" font-weight: normal;\n"
"}\n"
"\n"
"")

        self.formLayout.setWidget(0, QFormLayout.FieldRole, self.text_5)

        self.label = QLabel(self.formLayoutWidget)
        self.label.setObjectName(u"label")
        self.label.setStyleSheet(u"\n"
"QLabel#label{\n"
" background-color: rgb(255, 204, 255);\n"
"color: black;                /* Font color */\n"
"font: bold 17pt \"Arial Narrow\";\n"
" font-weight: normal;\n"
"}\n"
"")

        self.formLayout.setWidget(1, QFormLayout.FieldRole, self.label)

        self.horizontalLayoutWidget_2 = QWidget(self.tab_2)
        self.horizontalLayoutWidget_2.setObjectName(u"horizontalLayoutWidget_2")
        self.horizontalLayoutWidget_2.setGeometry(QRect(20, 220, 451, 41))
        self.horizontalLayout_2 = QHBoxLayout(self.horizontalLayoutWidget_2)
        self.horizontalLayout_2.setObjectName(u"horizontalLayout_2")
        self.horizontalLayout_2.setContentsMargins(0, 0, 0, 0)
        self.xml_file_mmpa = QLineEdit(self.horizontalLayoutWidget_2)
        self.xml_file_mmpa.setObjectName(u"xml_file_mmpa")
        sizePolicy2.setHeightForWidth(self.xml_file_mmpa.sizePolicy().hasHeightForWidth())
        self.xml_file_mmpa.setSizePolicy(sizePolicy2)
        self.xml_file_mmpa.setStyleSheet(u"QLineEdit {\n"
"    background-color: #ffffff;\n"
"    border: 2px solid #000;\n"
"}")

        self.horizontalLayout_2.addWidget(self.xml_file_mmpa)

        self.pushButton_4 = QPushButton(self.horizontalLayoutWidget_2)
        self.pushButton_4.setObjectName(u"pushButton_4")
        sizePolicy1.setHeightForWidth(self.pushButton_4.sizePolicy().hasHeightForWidth())
        self.pushButton_4.setSizePolicy(sizePolicy1)
        self.pushButton_4.setStyleSheet(u"QPushButton{\n"
"    background-color: rgb(167, 255, 200);  /* Bluish background */\n"
"    color: rgb(148, 0, 111);               /* Font color for the text */\n"
"    font: bold 8pt \"MS Shell Dlg 2\";\n"
"    padding: 5px;\n"
"    border-radius: 5px;                   /* Rounded corners */\n"
"    border: 2px solid rgb(85, 0, 127);           \n"
"}")

        self.horizontalLayout_2.addWidget(self.pushButton_4)

        self.text_15 = QLabel(self.tab_2)
        self.text_15.setObjectName(u"text_15")
        self.text_15.setGeometry(QRect(30, 180, 251, 33))
        sizePolicy.setHeightForWidth(self.text_15.sizePolicy().hasHeightForWidth())
        self.text_15.setSizePolicy(sizePolicy)
        self.text_15.setLayoutDirection(Qt.LeftToRight)
        self.text_15.setStyleSheet(u"\n"
"QLabel#text_15{\n"
" background-color: rgb(255, 204, 255);\n"
"color: black;                /* Font color */\n"
"font: bold 17pt \"Arial Narrow\";\n"
" font-weight: normal;\n"
"}\n"
"\n"
"")
        self.verticalLayoutWidget = QWidget(self.tab_2)
        self.verticalLayoutWidget.setObjectName(u"verticalLayoutWidget")
        self.verticalLayoutWidget.setGeometry(QRect(20, 110, 551, 51))
        self.verticalLayout = QVBoxLayout(self.verticalLayoutWidget)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.verticalLayout.setContentsMargins(0, 0, 0, 0)
        self.label_2 = QLabel(self.verticalLayoutWidget)
        self.label_2.setObjectName(u"label_2")
        self.label_2.setStyleSheet(u"\n"
"QLabel#label_2{\n"
" background-color: rgb(255, 204, 255);\n"
"color: black;                /* Font color */\n"
"font: 12pt \"Arial Narrow\";\n"
" font-weight: normal;\n"
"}\n"
"")

        self.verticalLayout.addWidget(self.label_2)

        self.label_3 = QLabel(self.tab_2)
        self.label_3.setObjectName(u"label_3")
        self.label_3.setGeometry(QRect(20, 280, 441, 61))
        self.label_3.setStyleSheet(u"\n"
"QLabel#label_3{\n"
" background-color: rgb(255, 204, 255);\n"
"color: black;                /* Font color */\n"
"font: bold 17pt \"Arial Narrow\";\n"
" font-weight: normal;\n"
"}\n"
"")
        self.verticalLayoutWidget_2 = QWidget(self.tab_2)
        self.verticalLayoutWidget_2.setObjectName(u"verticalLayoutWidget_2")
        self.verticalLayoutWidget_2.setGeometry(QRect(20, 340, 431, 199))
        self.verticalLayout_2 = QVBoxLayout(self.verticalLayoutWidget_2)
        self.verticalLayout_2.setObjectName(u"verticalLayout_2")
        self.verticalLayout_2.setContentsMargins(0, 0, 0, 0)
        self.checkBox_1 = QCheckBox(self.verticalLayoutWidget_2)
        self.checkBox_1.setObjectName(u"checkBox_1")
        self.checkBox_1.setStyleSheet(u"\n"
"\n"
"QCheckBox#checkBox_1 {\n"
"    background-color: rgb(255, 204, 255); \n"
"    color: black;                       \n"
"    font: normal 17pt \"Arial Narrow\";   \n"
"}\n"
"\n"
"QCheckBox#checkBox_1::indicator {\n"
"background-color: white; \n"
"    width: 40px; \n"
"    height: 40px; \n"
"}\n"
"\n"
"QCheckBox#checkBox_1::indicator:unchecked {\n"
"    image: url(\"L:/Internship/GUI/safepgutility/src/icons/unchecked.svg\"); \n"
"}\n"
"\n"
"QCheckBox#checkBox_1::indicator:checked {\n"
"    image: url(\"L:/Internship/GUI/safepgutility/src/icons/checked.svg\"); \n"
"}")

        self.verticalLayout_2.addWidget(self.checkBox_1)

        self.checkBox_2 = QCheckBox(self.verticalLayoutWidget_2)
        self.checkBox_2.setObjectName(u"checkBox_2")
        self.checkBox_2.setStyleSheet(u"QCheckBox#checkBox_2 {\n"
"    background-color: rgb(255, 204, 255); \n"
"    color: black;                       \n"
"    font: normal 17pt \"Arial Narrow\";   \n"
"}\n"
"\n"
"QCheckBox#checkBox_2::indicator {\n"
"background-color: white; \n"
"    width: 40px; \n"
"    height: 40px; \n"
"}\n"
"\n"
"QCheckBox#checkBox_2::indicator:unchecked {\n"
"    image: url(\"L:/Internship/GUI/safepgutility/src/icons/unchecked.svg\"); \n"
"}\n"
"\n"
"QCheckBox#checkBox_2::indicator:checked {\n"
"    image: url(\"L:/Internship/GUI/safepgutility/src/icons/checked.svg\"); \n"
"}\n"
"")

        self.verticalLayout_2.addWidget(self.checkBox_2)

        self.checkBox_3 = QCheckBox(self.verticalLayoutWidget_2)
        self.checkBox_3.setObjectName(u"checkBox_3")
        self.checkBox_3.setStyleSheet(u"QCheckBox#checkBox_3 {\n"
"    background-color: rgb(255, 204, 255); \n"
"    color: black;                       \n"
"    font: normal 17pt \"Arial Narrow\";   \n"
"}\n"
"\n"
"QCheckBox#checkBox_3::indicator {\n"
"background-color: white; \n"
"    width: 40px; \n"
"    height: 40px; \n"
"}\n"
"\n"
"QCheckBox#checkBox_3::indicator:unchecked {\n"
"    image: url(\"L:/Internship/GUI/safepgutility/src/icons/unchecked.svg\"); \n"
"}\n"
"\n"
"QCheckBox#checkBox_3::indicator:checked {\n"
"    image: url(\"L:/Internship/GUI/safepgutility/src/icons/checked.svg\"); \n"
"}\n"
"")

        self.verticalLayout_2.addWidget(self.checkBox_3)

        self.checkBox_4 = QCheckBox(self.verticalLayoutWidget_2)
        self.checkBox_4.setObjectName(u"checkBox_4")
        self.checkBox_4.setStyleSheet(u"QCheckBox#checkBox_4{\n"
"    background-color: rgb(255, 204, 255); \n"
"    color: black;                       \n"
"    font: normal 17pt \"Arial Narrow\";   \n"
"}\n"
"\n"
"QCheckBox#checkBox_4::indicator {\n"
"background-color: white; \n"
"    width: 40px; \n"
"    height: 40px; \n"
"}\n"
"\n"
"QCheckBox#checkBox_4::indicator:unchecked {\n"
"    image: url(\"L:/Internship/GUI/safepgutility/src/icons/unchecked.svg\"); \n"
"}\n"
"\n"
"QCheckBox#checkBox_4::indicator:checked {\n"
"    image: url(\"L:/Internship/GUI/safepgutility/src/icons/checked.svg\"); \n"
"}")

        self.verticalLayout_2.addWidget(self.checkBox_4)

        self.label_5 = QLabel(self.tab_2)
        self.label_5.setObjectName(u"label_5")
        self.label_5.setGeometry(QRect(20, 550, 771, 221))
        self.label_5.setStyleSheet(u"QLabel#label_4{\n"
" background-color: rgb(255, 204, 255);\n"
"color: black;                /* Font color */\n"
"font: 12pt  \"Arial Narrow\";\n"
" font-weight: normal;\n"
"}")
        self.tabWidget.addTab(self.tab_2, "")

        self.gridLayout_2.addWidget(self.tabWidget, 2, 0, 1, 1)

        MainWindow.setCentralWidget(self.centralwidget)
        self.menuBar = QMenuBar(MainWindow)
        self.menuBar.setObjectName(u"menuBar")
        self.menuBar.setGeometry(QRect(0, 0, 1264, 26))
        self.menuFile = QMenu(self.menuBar)
        self.menuFile.setObjectName(u"menuFile")
        MainWindow.setMenuBar(self.menuBar)

        self.menuBar.addAction(self.menuFile.menuAction())
        self.menuFile.addAction(self.actionOpen)
        self.menuFile.addAction(self.actionSave)
        self.menuFile.addAction(self.actionSave_As)

        self.retranslateUi(MainWindow)

        self.tabWidget.setCurrentIndex(0)


        QMetaObject.connectSlotsByName(MainWindow)
    # setupUi

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(QCoreApplication.translate("MainWindow", u"MainWindow", None))
        self.actionOpen.setText(QCoreApplication.translate("MainWindow", u"Open", None))
        self.actionSave.setText(QCoreApplication.translate("MainWindow", u"Save", None))
        self.actionSave_As.setText(QCoreApplication.translate("MainWindow", u"Save As", None))
        self.Number_label.setText(QCoreApplication.translate("MainWindow", u" 1", None))
        self.text.setText(QCoreApplication.translate("MainWindow", u"Scale the Stresses and Modify the Temperature      ", None))
        self.pushButton_2.setText(QCoreApplication.translate("MainWindow", u"Browse", None))
        self.text_6.setText(QCoreApplication.translate("MainWindow", u"Merge Local xml into Global xml", None))
        self.text_9.setText(QCoreApplication.translate("MainWindow", u"Temp", None))
        self.text_8.setText(QCoreApplication.translate("MainWindow", u"Multiplier    ", None))
        self.text_16.setText(QCoreApplication.translate("MainWindow", u"Local xml + Global xml & Run TMF", None))
        self.pushButton_6.setText(QCoreApplication.translate("MainWindow", u"Submit", None))
#if QT_CONFIG(tooltip)
        self.temp_adder_1.setToolTip(QCoreApplication.translate("MainWindow", u"Invalid value", None))
#endif // QT_CONFIG(tooltip)
        self.pushButton_3.setText(QCoreApplication.translate("MainWindow", u"Browse", None))
        self.text_4.setText(QCoreApplication.translate("MainWindow", u"TMF Input file (Required for TMF)", None))
        self.text_3.setText(QCoreApplication.translate("MainWindow", u"Global xml file", None))
        self.pushButton.setText(QCoreApplication.translate("MainWindow", u"Browse", None))
        self.text_10.setText(QCoreApplication.translate("MainWindow", u"Adder(In C)", None))
        self.text_7.setText(QCoreApplication.translate("MainWindow", u"Stress", None))
        self.text_14.setText(QCoreApplication.translate("MainWindow", u"Adder(In C)", None))
        self.text_2.setText(QCoreApplication.translate("MainWindow", u"Local xml file", None))
        self.text_13.setText(QCoreApplication.translate("MainWindow", u"Temp", None))
        self.pushButton_5.setText(QCoreApplication.translate("MainWindow", u"Submit", None))
        self.text_11.setText(QCoreApplication.translate("MainWindow", u"Multiplier", None))
        self.text_12.setText(QCoreApplication.translate("MainWindow", u"Stress", None))
        self.label_4.setText(QCoreApplication.translate("MainWindow", u"<html><head/><body><p align=\"justify\"><span style=\" font-size:11pt;\">NOTE:This tool is provided for stress multiplier, temperature adder &amp; quick life <br/> calculation purposes only. It acts as a stress multiplier and approximates comp<br/>onent life.Please note that it considers only mechanical stresses; thermal stress<br/>es are not taken into account. Users should exercise discretion when interpreting<br/>the results.It acts as a stress multiplier and approximates component life. Please <br/>note that it considers only and consider other factors not covered by this tool.<br/>The accuracy of results may vary due to geometric changes and other limitations<br/> inherent to the model approximation (intended for quick MI assessment such,<br/>as minor manufacturing deviations, minor field issues, etc).<br/>Use this tool responsibly and consult with MI experts for critical applications.<br/>By using this tool, you acknowledge and accept its limitations. </span></p></body></html>", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab), QCoreApplication.translate("MainWindow", u"Tab 1", None))
        self.Number_label_2.setText(QCoreApplication.translate("MainWindow", u"2", None))
        self.text_5.setText(QCoreApplication.translate("MainWindow", u"Convert xml file from M_MPa Unit ", None))
        self.label.setText(QCoreApplication.translate("MainWindow", u"System to mm_MPa Unit System", None))
        self.pushButton_4.setText(QCoreApplication.translate("MainWindow", u"Browse", None))
        self.text_15.setText(QCoreApplication.translate("MainWindow", u"xml file in M MPa Unit", None))
        self.label_2.setText(QCoreApplication.translate("MainWindow", u"Nodal coordinates scaled by 1.0E3, Nodal Stresses scaled by 1.0E-6", None))
        self.label_3.setText(QCoreApplication.translate("MainWindow", u"Select the box if the given xml file has :", None))
        self.checkBox_1.setText(QCoreApplication.translate("MainWindow", u"Nodal Temperature", None))
        self.checkBox_2.setText(QCoreApplication.translate("MainWindow", u"Nodal Coordinates", None))
        self.checkBox_3.setText(QCoreApplication.translate("MainWindow", u"Element Connectivities", None))
        self.checkBox_4.setText(QCoreApplication.translate("MainWindow", u"Nodal Stresses", None))
        self.label_5.setText(QCoreApplication.translate("MainWindow", u"<html><head/><body><p align=\"justify\"><span style=\" font-size:11pt;\">NOTE:This tool is provided for stress multiplier, temperature adder &amp; quick life <br/>calculation purposes only. It acts as a stress multiplier and approximates comp<br/>onent life.Please note that it considers only mechanical stresses; thermal stress<br/>es are not taken into account. Users should exercise discretion when interpreting<br/>the results.It acts as a stress multiplier and approximates component life. Please <br/>note that it considers only and consider other factors not covered by this tool.<br/>The accuracy of results may vary due to geometric changes and other limitations<br/> inherent to the model approximation (intended for quick MI assessment such,<br/>as minor manufacturing deviations, minor field issues, etc).<br/>Use this tool responsibly and consult with MI experts for critical applications.<br/>By using this tool, you acknowledge and accept its limitations. </span></p></body></html>", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab_2), QCoreApplication.translate("MainWindow", u"Tab 2", None))
        self.menuFile.setTitle(QCoreApplication.translate("MainWindow", u"File", None))
    # retranslateUi

